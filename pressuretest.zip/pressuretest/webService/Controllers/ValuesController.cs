﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Text;

namespace pressuretest.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        public ValuesController(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }
        // GET api/values
        [HttpGet]
        public string Get()
        {
            return "get";
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public string Post([FromBody]string value)
        {
            Request.Body.Position = 0;
            var reader = new StreamReader(Request.Body,true);
            var inputValue = reader.ReadToEnd();
            return inputValue;
            
            /*string webRootPath = _hostingEnvironment.WebRootPath;    
            string dataPath = webRootPath + "\\data\\book.xml"; 
            XElement  xml = XElement.Load(dataPath);  
            IEnumerable<XElement> ids =  
                from el in xml.Elements("book")  
                where (string)el.Attribute("id") == "tt113"  
                select el;  
            var valueFromFile = ids.FirstOrDefault().Element("author").Value;
            if(valueFromFile == value)
                return "success";
            else 
                return "fail";*/
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
